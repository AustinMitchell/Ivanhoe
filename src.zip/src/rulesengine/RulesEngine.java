package rulesengine;

import java.util.ArrayList;

import models.Card;

public class RulesEngine {

	public ArrayList<Card> valueCards(ArrayList display, String color, int value) {
		
		return display;
	}
	
	public ArrayList
}
