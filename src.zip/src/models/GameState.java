package models;
import rulesengine.Type;

import java.util.ArrayList;

public class GameState {
	private int tournamentNumber;
	private int tournamentColour;
	private ArrayList<Player> players;
	private Deck drawDeck;
	private Deck discardDeck;
	
	private static final int[] cardTypeData = {Type.PURPLE, Type.PURPLE, Type.PURPLE, Type.PURPLE, Type.PURPLE, 
												Type.PURPLE, Type.PURPLE, Type.PURPLE, Type.PURPLE, Type.PURPLE, 
												Type.PURPLE, Type.PURPLE, Type.PURPLE, Type.PURPLE, Type.RED, 
												Type.RED, Type.RED, Type.RED, Type.RED, Type.RED, 
												Type.RED, Type.RED, Type.RED, Type.RED, Type.RED, 
												Type.RED, Type.RED, Type.RED, Type.BLUE, Type.BLUE, 
												Type.BLUE, Type.BLUE, Type.BLUE, Type.BLUE, Type.BLUE, 
												Type.BLUE, Type.BLUE, Type.BLUE, Type.BLUE, Type.BLUE, 
												Type.BLUE, Type.BLUE, Type.YELLOW, Type.YELLOW, Type.YELLOW, 
												Type.YELLOW, Type.YELLOW, Type.YELLOW, Type.YELLOW, Type.YELLOW, 
												Type.YELLOW, Type.YELLOW, Type.YELLOW, Type.YELLOW, Type.YELLOW, 
												Type.YELLOW, Type.GREEN, Type.GREEN, Type.GREEN, Type.GREEN, 
												Type.GREEN, Type.GREEN, Type.GREEN, Type.GREEN, Type.GREEN, 
												Type.GREEN, Type.GREEN, Type.GREEN, Type.GREEN, Type.GREEN, 
												Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, 
												Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, 
												Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, 
												Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, Type.WHITE, 
												Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION, 
												Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION, 
												Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION, 
												Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION, Type.ACTION};
	
	private static final int[] cardValueData = {3, 3, 3, 3, 4, 
												4, 4, 4, 5, 5, 
												5, 5, 7, 7, 3, 
												3, 3, 3, 3, 3, 
												4, 4, 4, 4, 4, 
												4, 5, 5, 2, 2, 
												2, 2, 3, 3, 3, 
												3, 4, 4, 4, 4, 
												5, 5, 2, 2, 2, 
												2, 3, 3, 3, 3, 
												3, 3, 3, 3, 4, 
												4, 1, 1, 1, 1, 
												1, 1, 1, 1, 1, 
												1, 1, 1, 1, 1, 
												2, 2, 2, 2, 2, 
												2, 2, 2, 3, 3, 
												3, 3, 3, 3, 3, 
												3, 6, 6, 6, 6, 
												Card.UNHORSE, Card.CHANGE_WEAPON, Card.DROP_WEAPON, Card.BREAK_LANCE, Card.RIPOSTE, 
												Card.DODGE, Card.RETREAT, Card.KNOCKDOWN, Card.OUTMANEUVER, Card.CHARGE, 
												Card.COUNTERCHARGE, Card.DISGRACE, Card.ADAPT, Card.OUTWIT, Card.SHIELD, 
												Card.STUNNED, Card.IVANHOE, Card.RIPOSTE, Card.RIPOSTE, Card.KNOCKDOWN};
	
	public GameState(ArrayList<Player> newPlayers) {
		players = newPlayers;
		drawDeck = new Deck();
		for(int i = 0; i < 110; i++) {
			Card card = new Card(cardValueData[i], cardTypeData[i]);
			drawDeck.add(card);
		}
		drawDeck.shuffle();
		discardDeck = new Deck();
		tournamentNumber = 1;
		setUpStartingHands();
	}
	
	public Player getPlayer(String pName) {
		Player player = null;
		for(int i = 0; i < players.size(); i++) {
			if(pName.equals(String.valueOf(players.get(i).getName()))) {
				player = players.get(i);
			}
		}
		return player;
	}
	
	public void setTournamentColour(int colour) {
		tournamentColour = colour;
	}
	
	public int getTournamentColour() {
		return tournamentColour;
	}
	
	public void incrementTournamentNumber() {
		tournamentNumber++;
	}
	
	public int getTournamentNumber() {
		return tournamentNumber;
	}
	
	public Deck getDrawDeck() {
		return drawDeck;
	}
	
	public Deck getDiscardDeck() {
		return discardDeck;
	}
	
	//give each player 8 cards to start with at the beginning of a game
	public void setUpStartingHands() {
		for(int i = 0; i < players.size(); i++) {
			for(int j = 0; j < 8; j++) {
				drawDeck.draw(players.get(i).getHand());
			}
		}
	}
	
	public void renewDrawDeck() {
		drawDeck = discardDeck;
		drawDeck.shuffle();
		discardDeck = new Deck();
	}
	
	
	
}
