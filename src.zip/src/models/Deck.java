package models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Deck {
	private int cardNum;
	private ArrayList<Card> deck;
	
	public Deck() {
		deck = new ArrayList();
	}
	
	public void shuffle() {
		long seed = System.nanoTime();
		Collections.shuffle(deck, new Random(seed));
	}
	
	public void add(Card card) {
		deck.add(card);
	}
	
	public void moveCardTo(int pos, Deck newDeck) {
		Card card = deck.get(pos);
		deck.remove(pos);
		newDeck.add(card);
	}
	
	public void draw(Deck newDeck) {
		moveCardTo(deck.size(), newDeck);
	}
	
	public int deckSize() {
		cardNum = deck.size();
		return cardNum;
	}
	
	public Card getCard(int i) {
		return deck.get(i);
	}
	
	/*
	public ArrayList<Card> getDeck() {
		return deck;
	}
	*/
	
}
