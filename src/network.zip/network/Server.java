package network;

import models.*;
import rulesengine.*; // does contain parser, etc?
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.*;

public class Server{
	public static final int   PORT = 5000;
	private BufferedReader    streamIn = null;
	private BufferedWriter    streamOut = null;
	private ServerSocket      serverSocket;
	private RulesEngine       rules;
	private GameState         game;
	private int          	  numOfPlayers;
	private ArrayList<Player> players;
	private ArrayList<Socket> sockets;

	private ArrayList<OutputStream> toClientStreams;
	private ArrayList<InputStream> fromClientStreams;
	
    private ArrayList<DataOutputStream> out;
    private ArrayList<DataInputStream> in;

	private String updateString;
	
	public Server(int port, int maxPlayers) throws IOException {
		numOfPlayers = maxPlayers;
		sockets = new ArrayList<Socket>();
		serverSocket = new ServerSocket(port);
		serverSocket.setSoTimeout(1000000);
		players = new ArrayList<Player>();
		toClientStreams = new ArrayList<OutputStream>();
		fromClientStreams = new ArrayList<InputStream>();
		in  = new ArrayList<DataInputStream>();
		out = new ArrayList<DataOutputStream>();
	}
	
	public int getNumOfPlayers() {
		return numOfPlayers;
	}
	
	public int getPlayerPort(int player) {
		return sockets.get(player).getLocalPort();
	}
	
	public InetAddress getPlayerInetAddress(int player) {
		return sockets.get(player).getLocalAddress();
	}
	
	public int getPlayerClientPort(int player) {
		return sockets.get(player).getPort();
	}
	
	public InetAddress getPlayerClientInetAddress(int player) {
		return sockets.get(player).getInetAddress();
	}
	
	public void acceptPlayer() {
		try {
			Socket pSocket = serverSocket.accept();
			DataInputStream in = new DataInputStream(pSocket.getInputStream());
            String name = in.readUTF();
            Player p = new Player(name);
            players.add(p);
            sockets.add(pSocket);
		}
		catch(SocketTimeoutException s) {
            System.out.println("Socket timed out!");
		}
		catch(IOException e) {
            e.printStackTrace();
		}
		
	}

	public void setupUpdateStreams() throws IOException {
		for(int i = 0; i < players.size(); i++) {
			//ArrayList<OutputStream> toClientStreams = new ArrayList<OutputStream>();
			toClientStreams.add(
					sockets.get(i).getOutputStream());
         	fromClientStreams.add(sockets.get(i).getInputStream());
         		out.add(new DataOutputStream(toClientStreams.get(i)));
         	//ArrayList<InputStream> fromClientStreams = new ArrayList<InputStream>();
         		in.add(new DataInputStream(fromClientStreams.get(i)));
		}
	}

	public String getUpdate(int turn) throws IOException {
		String update;
        update = in.get(game.getTurn()).readUTF();
		return update;
	}

	public void updateClients(String update) throws IOException {
		for(int i = 0; i < players.size(); i++) {
         	out.get(i).writeUTF(update);
		}
	}
	
	public String setupGame() {
		
		//players = new ArrayList<Player>();
		int i;
		for(i = 0; i < numOfPlayers; i++) {
			acceptPlayer();
		}
		game = new GameState();
		updateString = game.initializeServer(players); // make initializeServer return shuffled array of cards as string
		return updateString;
	}
	
	public void runGame() throws IOException {
		RulesEngine.startGame(game); // this should call static rules engine method and start first tournament
		while(true) {
			updateClients(updateString);
			updateString = getUpdate(game.getTurn());
			Parser.networkSplitter(updateString, game);
		}
		
	}
	
	public static void main(String[] args) {
		try {
			Server server = new Server(PORT, 3);
			server.updateString = server.setupGame();
			server.setupUpdateStreams();
			server.runGame();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		
	}
	
}

