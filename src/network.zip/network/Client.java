package network;

import models.*;
import rulesengine.*;

import java.net.*;
import java.util.LinkedList;
import java.util.Queue;
import java.io.*;

public class Client implements Runnable{
	private GameState game;
	
	
	
	//constructor
		public Client () {
			guiFlags = new LinkedList<String>();
			game = new GameState();
		}
	
	   public static void main(String [] args)
	   {
	      new Thread(new Client()).start();
	   }
	   
	   
	   public GameState getGame() {
		   synchronized(game) {
			   return game;
		   }
	   }
	

		@Override
		public void run() {
			String serverName = "localhost";
		      int port = Server.PORT;
		      try
		      {
		         System.out.println("Connecting to " + serverName + " on port " + port);
		         Socket client = new Socket(serverName, port);
		         System.out.println("Just connected to " + client.getRemoteSocketAddress());
		         
		         OutputStream outToServer = client.getOutputStream();
		         DataOutputStream out = new DataOutputStream(outToServer);
		         out.writeUTF("Ahmed");
		         
		         InputStream inFromServer = client.getInputStream();
		         DataInputStream in =  new DataInputStream(inFromServer);
		         String update = in.readUTF();
		         System.out.println(update);
		         Parser.networkSplitter(update, game);
		         //outToServer = client.getOutputStream();
		         //out = new DataOutputStream(outToServer);
		         //out.writeUTF(update);
		         
		         client.close();
		      }catch(IOException e)
		      {
		         e.printStackTrace();
		      }
			
		}
	
	
	
	
	
	/*
	 * =====================================================================================
	 * Creating guiFlags using a Queue where the flags will be stored
	 */
	
	private Queue<String> guiFlags;
	
	//check if the flag queue is empty
	//this is used by the GUI to figure out whether there is a need
	//to update the UI or not
	public boolean isFlagQueueEmpty() {
		return guiFlags.isEmpty();
	}
	
	
	/*
	 * add an incoming flag to guiFlags queue
	 * this method is capable of parsing multiple commands passed as a single string then
	 * add each command to the queue as a single string
	 * 
	 * NOTE: commands must be separated by the single line character "\n"
	 * 		 DO NOT insert spaces before or after that new line character 
	 */
	public void addGuiFlag(String flag) {
		
		if(flag.contains("$")) //check if there are multiple commands 
		{
			String commands[] = flag.split("$");
			for(int i = 0; i < commands.length; i++) {
				guiFlags.add(commands[i]);
				Parser.parse(commands[i].split(":"), game);
			}
		}
		else //the case of one single command
			guiFlags.add(flag);
	}
	
	
	//this function will remove the first flag as soon as it is read
	public String readGuiFlag() {
		String flag = guiFlags.peek();
		guiFlags.remove();
		return flag;
	}

	/*
	 * End of Flags preparation
	 * ======================================================================================
	 */
	
	
	
}
